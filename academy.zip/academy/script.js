// app.js

// بيانات المستخدمين والأخبار والمواعيد
let users = JSON.parse(localStorage.getItem("users")) || [{ username: "wolves", password: "123455" }];
let players = [];
let news = [
    "أخبار جديدة عن اللاعب محمد: تم ترقيته إلى مستوى أعلى.",
    "تدريب جديد في الأكاديمية يوم السبت القادم.",
    "مباراة ودية ضد أكاديمية أخرى الأسبوع المقبل."
];
let schedule = [
    { name: "تمرين عام", time: "2024-12-12T15:00" },
    { name: "مباراة ضد أكاديمية أخرى", time: "2024-12-15T18:00" }
];

// تسجيل المستخدم الجديد
function registerUser() {
    const username = document.getElementById("register-username").value;
    const password = document.getElementById("register-password").value;
    
    // التحقق من وجود المستخدم بالفعل
    if (users.some(user => user.username === username)) {
        alert("اسم المستخدم موجود بالفعل. يرجى اختيار اسم آخر.");
        return;
    }

    if (username && password) {
        // إضافة المستخدم إلى قاعدة البيانات
        users.push({ username, password });
        // حفظ البيانات في localStorage
        localStorage.setItem("users", JSON.stringify(users));
        alert("تم إنشاء الحساب بنجاح. يمكنك الآن تسجيل الدخول.");
        document.getElementById("register-username").value = '';
        document.getElementById("register-password").value = '';
        document.getElementById("register-section").style.display = "none";
        document.getElementById("login-section").style.display = "block";
    } else {
        alert("يرجى إدخال اسم المستخدم وكلمة المرور.");
    }
}

// تسجيل الدخول للمستخدم
function loginUser() {
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;
    
    // البحث عن المستخدم في قاعدة البيانات
    const user = users.find(user => user.username === username && user.password === password);
    
    if (user) {
        alert("تم تسجيل الدخول بنجاح!");
        // إخفاء قسم تسجيل الدخول وعرض الأقسام التي تحتوي على المحتوى
        document.getElementById("login-section").style.display = "none";
        document.getElementById("news-section").style.display = "block";
        document.getElementById("schedule-section").style.display = "block";
        document.getElementById("player-form").style.display = "block"; // السماح بإنشاء حسابات للاعبين
        
        displayNews();
        displaySchedule();
    } else {
        alert("اسم المستخدم أو كلمة المرور غير صحيحة.");
    }
}

// عرض الأخبار
function displayNews() {
    const newsList = document.getElementById("news-list");
    newsList.innerHTML = ""; // تفريغ القائمة قبل إضافة الأخبار
    news.forEach((item) => {
        const listItem = document.createElement("li");
        listItem.textContent = item;
        newsList.appendChild(listItem);
    });
}

// عرض مواعيد التمارين والمباريات
function displaySchedule() {
    const scheduleList = document.getElementById("schedule-list");
    scheduleList.innerHTML = ""; // تفريغ القائمة قبل إضافة المواعيد
    schedule.forEach((event) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${event.name} - ${new Date(event.time).toLocaleString()}`;
        scheduleList.appendChild(listItem);
    });
}

// إنشاء حساب لاعب
function createPlayer() {
    const playerName = document.getElementById("player-name").value;
    const playerLevel = document.getElementById("player-level").value;

    if (playerName && playerLevel) {
        players.push({ name: playerName, level: playerLevel });
        alert(`تم إنشاء حساب اللاعب ${playerName} بنجاح!`);
        document.getElementById("player-name").value = '';
        document.getElementById("player-level").value = '';
    } else {
        alert("يرجى إدخال جميع البيانات.");
    }
}
